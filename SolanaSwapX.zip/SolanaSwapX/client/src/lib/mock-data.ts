import solanaIcon from '@assets/generated_images/3d_solana_token_icon.png';
import usdcIcon from '@assets/generated_images/3d_usdc_token_icon.png';
import memeIcon from '@assets/generated_images/3d_meme_token_icon.png';

export interface Token {
  symbol: string;
  name: string;
  balance: number;
  price: number;
  icon: string;
  change24h: number;
}

export const TOKENS: Token[] = [
  {
    symbol: 'SOL',
    name: 'Solana',
    balance: 12.45,
    price: 145.20,
    icon: solanaIcon,
    change24h: 5.2,
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    balance: 2500.00,
    price: 1.00,
    icon: usdcIcon,
    change24h: 0.01,
  },
  {
    symbol: 'DOGE',
    name: 'Doge Coin', // Using meme icon
    balance: 500000,
    price: 0.0023,
    icon: memeIcon,
    change24h: -2.4,
  },
  {
    symbol: 'RAY',
    name: 'Raydium',
    balance: 0,
    price: 1.85,
    icon: 'https://cryptologos.cc/logos/raydium-ray-logo.png', // Fallback or use placeholder if needed, but keeping simple for now
    change24h: 1.1,
  }
];

export const CHART_DATA_1D = [
  { time: '00:00', value: 142.5 },
  { time: '04:00', value: 143.2 },
  { time: '08:00', value: 141.8 },
  { time: '12:00', value: 144.5 },
  { time: '16:00', value: 145.8 },
  { time: '20:00', value: 145.2 },
  { time: '23:59', value: 146.1 },
];

export const CHART_DATA_1W = [
  { time: 'Mon', value: 135.0 },
  { time: 'Tue', value: 138.5 },
  { time: 'Wed', value: 142.0 },
  { time: 'Thu', value: 139.5 },
  { time: 'Fri', value: 145.2 },
  { time: 'Sat', value: 148.0 },
  { time: 'Sun', value: 146.1 },
];

export const POOLS = [
  { pair: 'SOL-USDC', liquidity: '$450,230,122', volume24h: '$24,500,000', fee: '0.3%' },
  { pair: 'SOL-DOGE', liquidity: '$12,400,500', volume24h: '$5,200,000', fee: '1.0%' },
  { pair: 'RAY-USDC', liquidity: '$8,900,000', volume24h: '$1,100,000', fee: '0.3%' },
  { pair: 'DOGE-USDC', liquidity: '$2,100,000', volume24h: '$800,000', fee: '0.5%' },
];
