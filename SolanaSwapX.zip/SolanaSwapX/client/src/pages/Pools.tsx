import { Navbar } from "@/components/layout/Navbar";
import { POOLS } from "@/lib/mock-data";
import { Button } from "@/components/ui/button";
import bgImage from '@assets/generated_images/dark_cyberpunk_grid_background.png';

export default function Pools() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
       <div className="fixed inset-0 z-0">
        <img 
          src={bgImage} 
          alt="background" 
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background"></div>
      </div>

      <div className="relative z-10">
        <Navbar />
        
        <main className="container mx-auto px-4 py-12">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-4xl font-heading font-bold">Liquidity Pools</h1>
            <Button className="bg-primary text-background font-bold">Create Pool</Button>
          </div>

          <div className="glass-card rounded-2xl overflow-hidden border border-white/10">
            <div className="grid grid-cols-4 gap-4 p-4 border-b border-white/10 text-sm font-medium text-muted-foreground bg-white/5">
              <div>Pair</div>
              <div className="text-right">Liquidity</div>
              <div className="text-right">Volume (24h)</div>
              <div className="text-right">Fee</div>
            </div>
            
            <div className="divide-y divide-white/5">
              {POOLS.map((pool) => (
                <div key={pool.pair} className="grid grid-cols-4 gap-4 p-4 items-center hover:bg-white/5 transition-colors cursor-pointer group">
                  <div className="flex items-center gap-3">
                    <div className="flex -space-x-2">
                      <div className="w-8 h-8 rounded-full bg-primary/20 border-2 border-background"></div>
                      <div className="w-8 h-8 rounded-full bg-secondary/20 border-2 border-background"></div>
                    </div>
                    <span className="font-bold font-heading group-hover:text-primary transition-colors">{pool.pair}</span>
                  </div>
                  <div className="text-right font-mono">{pool.liquidity}</div>
                  <div className="text-right font-mono">{pool.volume24h}</div>
                  <div className="text-right font-mono text-green-400">{pool.fee}</div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
