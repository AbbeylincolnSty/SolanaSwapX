import { Navbar } from "@/components/layout/Navbar";
import { SwapCard } from "@/components/dex/SwapCard";
import { PriceChart } from "@/components/dex/PriceChart";
import bgImage from '@assets/generated_images/dark_cyberpunk_grid_background.png';
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/20">
      {/* Background with Overlay */}
      <div className="fixed inset-0 z-0">
        <img 
          src={bgImage} 
          alt="background" 
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background"></div>
      </div>

      <div className="relative z-10">
        <Navbar />
        
        <main className="container mx-auto px-4 py-8 lg:py-12">
          <div className="grid lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column: Chart & Stats */}
            <div className="lg:col-span-7 xl:col-span-8 space-y-6 hidden lg:block">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="h-[500px]"
              >
                <PriceChart />
              </motion.div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: "Total Vol", value: "$1.2B" },
                  { label: "Open Interest", value: "$840M" },
                  { label: "Active Users", value: "24.5k" },
                ].map((stat, i) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.1 * i }}
                    className="glass-card p-4 rounded-xl border-0 bg-white/5"
                  >
                    <div className="text-sm text-muted-foreground mb-1">{stat.label}</div>
                    <div className="text-2xl font-mono font-bold text-white">{stat.value}</div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Right Column: Swap Interface */}
            <div className="lg:col-span-5 xl:col-span-4 max-w-md mx-auto lg:max-w-none w-full">
               <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <SwapCard />
              </motion.div>
              
              <div className="mt-6 text-center">
                <p className="text-xs text-muted-foreground">
                  Powered by <span className="text-primary font-bold">Solana</span> • Low Fees • Instant Finality
                </p>
              </div>
            </div>

          </div>
        </main>
      </div>
    </div>
  );
}
