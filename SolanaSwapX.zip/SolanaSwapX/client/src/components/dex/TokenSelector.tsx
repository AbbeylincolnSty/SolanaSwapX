import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { TOKENS, Token } from "@/lib/mock-data";
import { useState } from "react";

interface TokenSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (token: Token) => void;
}

export function TokenSelector({ isOpen, onClose, onSelect }: TokenSelectorProps) {
  const [search, setSearch] = useState("");

  const filteredTokens = TOKENS.filter(
    (t) =>
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.symbol.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-card border-white/10 sm:max-w-[425px] p-0 gap-0 overflow-hidden">
        <DialogHeader className="p-4 pb-2 border-b border-white/5">
          <DialogTitle className="font-heading">Select Token</DialogTitle>
        </DialogHeader>
        
        <div className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or address"
              className="pl-9 bg-background/50 border-white/10 focus-visible:ring-primary/50"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2 mt-4 overflow-x-auto pb-2 no-scrollbar">
            {TOKENS.slice(0, 3).map((token) => (
              <button
                key={token.symbol}
                onClick={() => {
                  onSelect(token);
                  onClose();
                }}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/5 hover:bg-white/10 hover:border-primary/30 transition-all shrink-0"
              >
                <img src={token.icon} alt={token.symbol} className="w-5 h-5 rounded-full" />
                <span className="text-sm font-medium">{token.symbol}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="max-h-[300px] overflow-y-auto p-2">
          {filteredTokens.map((token) => (
            <button
              key={token.symbol}
              onClick={() => {
                onSelect(token);
                onClose();
              }}
              className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-white/5 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <img src={token.icon} alt={token.symbol} className="w-8 h-8 rounded-full group-hover:scale-110 transition-transform" />
                <div className="text-left">
                  <div className="font-bold font-heading">{token.symbol}</div>
                  <div className="text-xs text-muted-foreground">{token.name}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono text-sm">{token.balance > 0 ? token.balance.toLocaleString() : '0'}</div>
                <div className="text-xs text-muted-foreground">
                  ${(token.balance * token.price).toLocaleString()}
                </div>
              </div>
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
