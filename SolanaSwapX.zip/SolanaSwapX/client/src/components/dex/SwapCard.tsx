import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings, ArrowDownUp, ChevronDown, Wallet } from "lucide-react";
import { TokenSelector } from "./TokenSelector";
import { TOKENS, Token } from "@/lib/mock-data";
import { motion, AnimatePresence } from "framer-motion";

export function SwapCard() {
  const [payToken, setPayToken] = useState<Token>(TOKENS[0]); // SOL
  const [receiveToken, setReceiveToken] = useState<Token>(TOKENS[1]); // USDC
  const [payAmount, setPayAmount] = useState("");
  const [isSelectorOpen, setIsSelectorOpen] = useState(false);
  const [selectorMode, setSelectorMode] = useState<'pay' | 'receive'>('pay');

  // Mock conversion
  const receiveAmount = payAmount 
    ? (parseFloat(payAmount) * payToken.price / receiveToken.price).toFixed(4)
    : "";

  const handleSwitch = () => {
    setPayToken(receiveToken);
    setReceiveToken(payToken);
    setPayAmount(receiveAmount);
  };

  const openSelector = (mode: 'pay' | 'receive') => {
    setSelectorMode(mode);
    setIsSelectorOpen(true);
  };

  return (
    <div className="relative group">
      {/* Glow effect behind card */}
      <div className="absolute -inset-0.5 bg-gradient-to-br from-primary/30 to-secondary/30 rounded-2xl blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
      
      <Card className="relative glass-card border-0 p-4 space-y-2 overflow-hidden">
        <div className="flex items-center justify-between mb-2 px-2">
          <span className="font-heading font-bold text-lg">Swap</span>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-white/10">
            <Settings className="h-4 w-4 text-muted-foreground" />
          </Button>
        </div>

        {/* Pay Section */}
        <div className="bg-black/20 rounded-xl p-4 border border-white/5 hover:border-white/10 transition-colors">
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>You Pay</span>
            <span>Balance: {payToken.balance}</span>
          </div>
          <div className="flex items-center gap-3">
             <button 
              onClick={() => openSelector('pay')}
              className="flex items-center gap-2 bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-full transition-colors group/token"
            >
              <img src={payToken.icon} alt={payToken.symbol} className="w-6 h-6 rounded-full" />
              <span className="font-bold font-heading">{payToken.symbol}</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground group-hover/token:text-white transition-colors" />
            </button>
            <input 
              type="number" 
              placeholder="0.0"
              value={payAmount}
              onChange={(e) => setPayAmount(e.target.value)}
              className="w-full bg-transparent text-right text-2xl font-mono font-bold focus:outline-none placeholder:text-muted-foreground/30"
            />
          </div>
          <div className="text-right text-xs text-muted-foreground mt-2">
            ≈ ${payAmount ? (parseFloat(payAmount) * payToken.price).toFixed(2) : '0.00'}
          </div>
        </div>

        {/* Switch Button */}
        <div className="relative h-4 flex items-center justify-center z-10">
          <button 
            onClick={handleSwitch}
            className="absolute bg-card border border-white/10 p-2 rounded-xl hover:scale-110 hover:border-primary/50 hover:text-primary transition-all"
          >
            <ArrowDownUp className="h-4 w-4" />
          </button>
        </div>

        {/* Receive Section */}
        <div className="bg-black/20 rounded-xl p-4 border border-white/5 hover:border-white/10 transition-colors">
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>You Receive</span>
            <span>Balance: {receiveToken.balance}</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => openSelector('receive')}
              className="flex items-center gap-2 bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-full transition-colors group/token"
            >
              <img src={receiveToken.icon} alt={receiveToken.symbol} className="w-6 h-6 rounded-full" />
              <span className="font-bold font-heading">{receiveToken.symbol}</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground group-hover/token:text-white transition-colors" />
            </button>
            <input 
              type="text" 
              readOnly
              placeholder="0.0"
              value={receiveAmount}
              className="w-full bg-transparent text-right text-2xl font-mono font-bold focus:outline-none placeholder:text-muted-foreground/30 text-primary"
            />
          </div>
          <div className="text-right text-xs text-muted-foreground mt-2">
            ≈ ${receiveAmount ? (parseFloat(receiveAmount) * receiveToken.price).toFixed(2) : '0.00'}
          </div>
        </div>

        {/* Price Info */}
        {payAmount && (
          <div className="flex justify-between px-2 py-2 text-xs font-mono text-muted-foreground">
            <span>Rate</span>
            <span>1 {payToken.symbol} ≈ {(payToken.price / receiveToken.price).toFixed(4)} {receiveToken.symbol}</span>
          </div>
        )}

        <Button className="w-full h-14 text-lg font-bold bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity rounded-xl mt-4 shadow-[0_0_20px_rgba(25,251,155,0.3)]">
          Swap
        </Button>
      </Card>

      <TokenSelector 
        isOpen={isSelectorOpen} 
        onClose={() => setIsSelectorOpen(false)}
        onSelect={(token) => {
          if (selectorMode === 'pay') setPayToken(token);
          else setReceiveToken(token);
        }}
      />
    </div>
  );
}
