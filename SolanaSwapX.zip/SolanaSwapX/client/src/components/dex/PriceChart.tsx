import { Card } from "@/components/ui/card";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CHART_DATA_1D, CHART_DATA_1W } from "@/lib/mock-data";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export function PriceChart() {
  const [timeframe, setTimeframe] = useState<'1D' | '1W' | '1M'>('1D');
  
  const data = timeframe === '1D' ? CHART_DATA_1D : CHART_DATA_1W;
  
  // Determine color based on trend (mock logic)
  const isPositive = data[data.length - 1].value >= data[0].value;
  const color = isPositive ? "var(--color-primary)" : "var(--color-destructive)";

  return (
    <Card className="glass-card border-0 p-6 h-full flex flex-col">
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="h-6 w-6 rounded-full bg-gradient-to-br from-primary to-secondary" />
            <span className="font-heading font-bold text-xl">SOL / USDC</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-mono font-bold">$146.10</span>
            <span className={`text-sm font-mono ${isPositive ? 'text-primary' : 'text-destructive'}`}>
              {isPositive ? '+' : ''}2.45%
            </span>
          </div>
        </div>
        
        <div className="flex p-1 bg-black/20 rounded-lg border border-white/5">
          {(['1H', '1D', '1W', '1M'] as const).map((t) => (
            <button
              key={t}
              onClick={() => t !== '1H' && setTimeframe(t as any)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${
                timeframe === t 
                  ? 'bg-white/10 text-white shadow-sm' 
                  : 'text-muted-foreground hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 min-h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.3} />
                <stop offset="95%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'rgba(10, 10, 10, 0.8)', 
                borderColor: 'rgba(255,255,255,0.1)',
                backdropFilter: 'blur(8px)',
                borderRadius: '8px'
              }}
              itemStyle={{ color: '#fff' }}
              labelStyle={{ display: 'none' }}
              formatter={(value: number) => [`$${value.toFixed(2)}`, 'Price']}
            />
            <Area 
              type="monotone" 
              dataKey="value" 
              stroke={color} 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorPrice)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
