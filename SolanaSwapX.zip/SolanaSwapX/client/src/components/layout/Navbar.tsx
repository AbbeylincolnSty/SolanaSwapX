import { Link, useLocation } from "wouter";
import { Wallet, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Navbar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const links = [
    { href: "/", label: "Swap" },
    { href: "/pools", label: "Pools" },
    { href: "/analytics", label: "Analytics" },
  ];

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-white/5 bg-background/60 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-[0_0_15px_rgba(25,251,155,0.5)]">
            <span className="font-heading font-bold text-background">S</span>
          </div>
          <span className="font-heading text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
            SolEx
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              <a
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  isActive(link.href) ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {link.label}
              </a>
            </Link>
          ))}
        </div>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground bg-card/50 px-3 py-1.5 rounded-full border border-white/5">
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            Solana Mainnet
          </div>
          <Button className="bg-white text-black hover:bg-white/90 font-bold rounded-full">
            <Wallet className="mr-2 h-4 w-4" />
            Connect Wallet
          </Button>
        </div>

        {/* Mobile Menu */}
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="border-l border-white/10 bg-background/95 backdrop-blur-xl">
            <div className="flex flex-col gap-8 mt-8">
              {links.map((link) => (
                <Link key={link.href} href={link.href}>
                  <a className="text-lg font-medium text-foreground hover:text-primary">
                    {link.label}
                  </a>
                </Link>
              ))}
              <Button className="w-full bg-primary text-background font-bold">
                Connect Wallet
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}
